'use strict';
window.RadarNative=(()=>{
 const requests=new Map();let serial=0,epoch=0;
 function fetch(url,options){
  return new Promise((resolve,reject)=>{
   const id=String(++serial),timer=setTimeout(()=>{requests.delete(id);reject(new Error('Market request timed out'));},18000);
   requests.set(id,{resolve,reject,timer});
   try{Android.request(id,url,JSON.stringify(options));}catch(e){clearTimeout(timer);requests.delete(id);reject(e);}
  });
 }
 function receive(id,status,body,error){
  const item=requests.get(id);if(!item)return;requests.delete(id);clearTimeout(item.timer);
  if(error)item.reject(new Error(error));else item.resolve({ok:status>=200&&status<300,status,text:async()=>body});
 }
 function cancel(){
  epoch++;
  try{Android.cancel();}catch{}
  for(const item of requests.values()){clearTimeout(item.timer);item.reject(new Error('Monitoring paused'));}requests.clear();
 }
 return {fetch,receive,cancel,get epoch(){return epoch;}};
})();
