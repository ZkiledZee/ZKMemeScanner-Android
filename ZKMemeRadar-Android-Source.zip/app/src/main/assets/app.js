'use strict';
(()=>{
 const $=id=>document.getElementById(id),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const now=()=>Date.now()/1000,copy=v=>JSON.parse(JSON.stringify(v));
 const money=v=>v==null||!Number.isFinite(v)?'Unavailable':v===0?'$0':Math.abs(v)<1e-7?'$'+v.toPrecision(3):'$'+v.toLocaleString('en-US',{maximumFractionDigits:v<.01?8:v<1?5:2});
 const compact=v=>v==null?'—':v>=1e6?'$'+(v/1e6).toFixed(1)+'M':v>=1000?'$'+(v/1000).toFixed(1)+'K':money(v);
 const pct=v=>v==null?'—':(v>=0?'+':'')+v.toFixed(1)+'%';
 const disclaimer='Signals are algorithmic market observations and not guaranteed outcomes. Meme coins are highly speculative and can rapidly lose their entire value.';
 let saved={},tab='home',detail=null,selectedHistory=null,filter='Trending',chain='All',query='',orderSize='',busy=false,active=false,generation=0,timer=null,received=0,error='',events=[],storageError=false,cycleDuration=0,toastTimer;
 let watch=[];try{watch=JSON.parse(localStorage.getItem('watch')||'[]');if(!Array.isArray(watch))watch=[];}catch{}
 try{saved=JSON.parse(Android.readState());if(saved.storageError)throw Error('Storage');if(saved.state&&(!Array.isArray(saved.tokens)||!Array.isArray(saved.history)))throw Error('Invalid state');}catch{storageError=true;error='Saved signal state needs recovery. Scanning is paused to protect the active lock.';}
 const tokens=()=>saved.state?.candidates||[],signal=()=>saved.active||null;
 const fresh=()=>active&&now()-received<90&&saved.state?.live===true&&!error;
 const status=()=>!active?'PAUSED':fresh()?'LIVE':error?'RETRYING':tokens().length?'UPDATING':'DISCOVERING';
 function toast(text){$('toast').textContent=text;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),5000);}
 function log(text){if(events[0]?.text===text)return;events.unshift({text,time:now()});events=events.slice(0,12);}
 async function tick(){
  if(!active||busy||storageError)return;
  busy=true;const run=generation,began=now();let watchdog;
  renderStatus();
  try{
   const next=await Promise.race([cycle(copy(saved)),new Promise((_,reject)=>{watchdog=setTimeout(()=>reject(Error('Feed request timed out')),45000);})]);
   if(!active||run!==generation)return;
   const value=JSON.stringify(next);
   if(!Android.saveState(value))throw Error('Could not save signal state');
   const old=signal();saved=next;received=now();cycleDuration=now()-began;
   error=next.state.live||next.state.providers.some(p=>p.ok&&now()-p.at<120)?'':'Market feeds are delayed. Automatic retry is running.';
   log(next.phase||'Scanning available pools');
   const nextSignal=signal();
   if(nextSignal&&old?.id!==nextSignal.id){tab='signal';detail=null;selectedHistory=null;toast('Setup confirmed · '+nextSignal.token.symbol);Android.haptic();}
   else if(old&&old.id===nextSignal?.id&&old.recommendation!==nextSignal.recommendation){toast(nextSignal.recommendation);Android.haptic();}
   else if(old&&!nextSignal){toast(saved.history?.[0]?.status||'Signal closed');Android.haptic();}
   render();
  }catch(e){
   if(run===generation&&active){RadarNative.cancel();error='Feed interrupted — retrying automatically.';log('Market feed retry scheduled');renderStatus();}
  }finally{
   clearTimeout(watchdog);
   if(run===generation){busy=false;renderStatus();if(active)timer=setTimeout(tick,signal()?2000:3000);}
  }
 }
 function foreground(on){
  active=!!on;generation++;clearTimeout(timer);busy=false;RadarNative.cancel();
  document.body.classList.toggle('paused',!active);render();
  if(active&&!storageError){if(typeof cycle!=='function'){error='Update Android System WebView, then reopen Radar.';renderStatus();return;}timer=setTimeout(tick,150);}
 }
 function renderStatus(){
  $('notice').textContent=storageError?error:!active?'Monitoring paused while away':error||(received===0&&tokens().length?'Restoring observations · checking fresh prices':'');
  document.querySelectorAll('[data-status]').forEach(el=>{el.textContent=status();el.classList.toggle('warn',!fresh());});
  document.querySelectorAll('[data-phase]').forEach(el=>el.textContent=active?(saved.phase||'Opening public market feeds'):'Monitoring paused');
  document.querySelectorAll('[data-busy]').forEach(el=>el.textContent=busy?'Checking live observations':'Next scan automatically');
 }
 const badge=()=>`<span class="badge ${fresh()?'':'warn'}"><span class="status-dot"></span><span data-status>${status()}</span></span>`;
 function avatar(t){let image='';try{const u=new URL(t.iconURL);if(u.protocol==='https:')image=`<img src="${esc(u.href)}" alt="" loading="lazy" referrerpolicy="no-referrer">`;}catch{}return `<span class="avatar">${esc(t.symbol.slice(0,2))}${image}</span>`;}
 function spark(t){const pts=(t.points||[]).slice(-35);if(pts.length<2)return '<span class="spark"></span>';const values=pts.map(p=>p.price),min=Math.min(...values),range=Math.max(Math.max(...values)-min,min*1e-7,1e-14),path=values.map((v,i)=>(i?'L':'M')+(i*54/(values.length-1)).toFixed(1)+','+(25-(v-min)/range*22).toFixed(1)).join(' ');return `<svg class="spark" viewBox="0 0 54 28" aria-label="Observed price trend"><path d="${path}" fill="none" stroke="${(t.change5||0)>=0?'#66f4c8':'#ffc078'}" stroke-width="1.5"/></svg>`;}
 function row(t){return `<button class="token" data-token="${esc(t.id)}">${avatar(t)}<span class="grow"><strong>${esc(t.symbol)}</strong><small>${esc(t.chain.toUpperCase())} · ${compact(t.liquidity)} LIQ</small></span>${spark(t)}<span class="numbers">${money(t.price)}<small class="${(t.change5||0)>=0?'mint':'orange'}">${pct(t.change5)} · 5m</small></span></button>`;}
 function radar(large=false){return `<div class="radar ${large?'large':''}"><div class="ring"></div><div class="ring r2"></div><div class="sweep" style="animation-delay:-${now()%8}s"></div>${tokens().slice(0,24).map((t,i)=>{const angle=i*2.399963,r=46-(t.scores.Overall||0)/3;return `<span class="blip" style="left:${50+Math.cos(angle)*r}%;top:${50+Math.sin(angle)*r}%;animation-delay:${i*.13}s" title="${esc(t.symbol)}"></span>`;}).join('')}<div class="radar-center"><strong>◎</strong>${signal()?esc(signal().token.symbol):active?'SCANNING':'PAUSED'}</div></div>`;}
 const metric=(label,value)=>`<div class="metric"><small>${esc(label)}</small><b>${value}</b></div>`;
 const list=values=>`<ul class="list">${values.length?values.map(v=>`<li>${esc(v)}</li>`).join(''):'<li>No verified evidence yet</li>'}</ul>`;
 const panel=(title,body)=>`<section class="panel"><div class="eyebrow">${esc(title)}</div>${body}</section>`;
 function activity(){return panel('Scanner activity',events.length?events.slice(0,4).map(e=>`<div class="activity"><i>⌁</i><span>${esc(e.text)}</span><time>${new Date(e.time*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</time></div>`).join(''):'<p class="quiet">Connecting to live market feeds…</p>');}
 function home(){
  const ts=tokens(),warm=ts.filter(t=>t.points.length>=10&&t.points.at(-1).time-t.points[0].time>=300).length,safe=ts.filter(t=>t.security.complete&&!t.security.danger&&now()-t.security.checked<180).length;
  return `<section class="panel"><div class="row between"><span class="eyebrow">${signal()?'One signal · locked':'Searching for an edge'}</span>${badge()}</div>${radar()}<div class="scan-phase" data-phase></div><div class="scan-note" data-busy></div><div class="metrics">${metric('Observed',ts.length)}${metric('Watching',saved.state?.potential||0)}${metric('Signal',signal()?1:0)}</div></section>`+
  (signal()?`<button class="token signal-panel" data-tab="signal">${avatar(signal().token)}<span class="grow"><small>YOUR ACTIVE SIGNAL</small><strong>${esc(signal().token.symbol)}</strong><p class="mint">${esc(fresh()&&now()-signal().lastGood<60?signal().recommendation:'Verifying conditions')}</p></span><span class="mint">↗</span></button>`:`<div class="row" style="padding:5px 4px 19px"><span class="mint" style="font-size:33px">◎</span><div><h3>Waiting for confirmation</h3><p style="font-size:11px">A qualifying entry opens the Signal screen with its targets and evidence.</p></div></div>`)+
  panel('Entry readiness',`<div class="readiness">${[['Observed',ts.length],['Warmed up',warm],['Security',safe]].map(([name,n])=>`<div><b>${n}</b><div class="bar"><div style="width:${n/Math.max(1,ts.length)*100}%"></div></div><small>${name}</small></div>`).join('')}</div><p class="footnote">Requires at least 5 minutes and 10 samples per coin, a confirmed retest and fresh security evidence. Unknown checks block entry.</p>`)+
  `<div class="section-head"><span class="eyebrow">Leading candidates</span><button data-tab="market">All markets →</button></div>${ts.slice(0,5).map(row).join('')}`+activity()+`<p class="footnote">Screen stays awake while scanning. Leaving the app pauses monitoring. Feed coverage is partial; observed tokens can include non-meme assets.</p><p class="footnote">${disclaimer}</p>`;
 }
 function chart(t,s){
  const pts=t.points||[];if(pts.length<2)return '<div class="chart-empty">Building real price history</div>';
  const lines=s?[s.entry,s.stop,s.target1]:[],values=pts.map(p=>p.price).concat(lines),lo=Math.min(...values),range=Math.max(Math.max(...values)-lo,lo*1e-5,1e-14),y=v=>145-(v-lo)/range*130,path=pts.map((p,i)=>(i?'L':'M')+(i*320/(pts.length-1)).toFixed(1)+','+y(p.price).toFixed(1)).join(' ');
  return `<svg class="chart" viewBox="0 0 320 160" role="img" aria-label="Sampled market price chart">${[35,75,115].map(h=>`<path d="M0 ${h} H320" stroke="#ffffff08"/>`).join('')}${s?[[s.entry,'ENTRY','#87aaff'],[s.stop,'STOP','#ffc078'],[s.target1,'TP1','#66f4c8']].map(([v,n,c])=>`<path d="M0 ${y(v)} H320" stroke="${c}" stroke-dasharray="3 4" opacity=".4"/><text x="3" y="${y(v)-4}" fill="${c}" font-size="7">${n}</text>`).join(''):''}<path d="${path}" stroke="#66f4c8" stroke-width="2" fill="none"/><circle cx="320" cy="${y(pts.at(-1).price)}" r="3" fill="#66f4c8"/></svg><div class="row between quiet"><span>${new Date(pts[0].time*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</span><span>OBSERVED USD PRICE</span><span>${new Date(pts.at(-1).time*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</span></div>`;
 }
 function signalPage(){
  const s=selectedHistory?(saved.history||[]).find(h=>h.id===selectedHistory):signal();
  if(!s)return `<h1>Signal</h1><section class="panel empty"><div class="emblem">◎</div><h2>No confirmed entry yet</h2><p>The scanner is checking momentum, liquidity, volume, security and entry timing. It will select one qualifying coin at a time.</p><button class="primary" data-tab="market">Explore candidates</button></section>${activity()}`;
  const valid=fresh()&&now()-s.lastGood<60&&now()<s.expires,t=s.token;
  return `${selectedHistory?'<button class="back" data-tab="history">← Signal history</button>':''}<div class="row between" style="margin:6px 0 18px">${avatar(t)}<div class="grow"><h1 style="margin:0">${esc(t.symbol)}</h1><small class="muted">${esc(t.name)}</small></div><span class="badge">${esc(t.chain.toUpperCase())}</span></div>`+
  panel(s.closed?'Recorded observation':'One coin. One focus.',`<p class="badge ${!valid||s.closed?'warn':''}">${esc(s.closed?s.status:valid?s.recommendation:'STALE — DO NOT ENTER')}</p><div class="price-large">${money(t.price)}</div>${chart(t,s)}<div class="metrics two">${metric('Entry reference',money(s.entry))}${metric('Invalidation',money(s.stop))}</div><p class="footnote">Entry zone: ${money(s.entryLow)} – ${money(s.entryHigh)}</p><div class="metrics two">${metric('Target 1 · 2R',money(s.target1))}${metric('Target 2 · 3R',money(s.target2))}</div>`)+
  (!s.closed?panel('Dynamic hold estimate',`<div class="metrics two" style="border:0;padding-top:0">${metric('Expected hold',Math.round((s.expires-s.opened)/60)+' MIN')}${metric('Countdown',`<span data-expires="${s.expires}" class="timer"></span>`)}</div><div class="bar"><div data-hold-bar="${s.opened}" data-end="${s.expires}"></div></div><p class="footnote">Estimate only. Exit conditions can change before time runs out.</p>`):panel(s.closeReason||'Closed',`<div class="metrics two">${metric('Observed exit',money(s.exit))}${metric('Time held',Math.floor((s.closed-s.opened)/60)+' MIN')}${metric('Max observed gain',pct(s.maxGain))}${metric('Max observed loss',pct(s.maxLoss))}</div>`))+
  panel('Signal assessment',`<div class="metrics two">${metric('Confidence score',Math.round(s.confidence)+'/100')}${metric('Rug risk score',t.scores['Rug Risk']==null?'Unknown':Math.round(t.scores['Rug Risk'])+'/100')}${metric('Target 2 reward',pct((s.target2/s.entry-1)*100))}${metric('Stop distance',pct((s.stop/s.entry-1)*100))}</div><p class="footnote">Heuristic scores, not probabilities. Prices exclude fees, tax and slippage. No orders are placed.</p>`)+panel('Why this signal',list(s.reasons))+panel('Risks and early exits',list(t.risks.concat(['Exit on invalidation, severe liquidity loss, security deterioration, sell dominance or hold expiry.'])))+`<button class="primary" data-token="${esc(t.id)}">Full token analysis</button><p class="footnote">${disclaimer}</p>`;
 }
 function filtered(){let ts=tokens().filter(t=>(chain==='All'||t.chain===chain)&&(!query||(t.symbol+' '+t.name+' '+t.address).toLowerCase().includes(query.toLowerCase())));if(filter==='Momentum')ts.sort((a,b)=>b.scores.Momentum-a.scores.Momentum);if(filter==='Volume')ts.sort((a,b)=>b.volume5-a.volume5);if(filter==='New')ts=ts.filter(t=>t.created&&now()-t.created<86400).sort((a,b)=>b.created-a.created);if(filter==='Watchlist')ts=ts.filter(t=>watch.includes(t.id));return ts;}
 function market(){return `<h1>Market</h1><p style="font-size:12px">Discovery only. The Signal tab holds the sole actionable setup.</p><div class="row" style="margin-top:16px"><input id="search" class="grow" aria-label="Search coins" placeholder="Search coin or contract" value="${esc(query)}"><select id="chain" aria-label="Chain">${['All','solana','base','ethereum','bsc'].map(c=>`<option ${chain===c?'selected':''} value="${c}">${c==='All'?'All chains':c.toUpperCase()}</option>`).join('')}</select></div><div class="filters">${['Trending','Momentum','New','Volume','Watchlist'].map(f=>`<button data-filter="${f}" class="${f===filter?'active':''}">${f}</button>`).join('')}</div><div id="results">${marketRows()}</div>`;}
 function marketRows(){const ts=filtered();return ts.length?ts.map(row).join(''):'<section class="panel empty"><h2>No matching observations</h2><p>Available candidates appear automatically. Watchlist shows currently observed coins.</p></section>';}
 function wheel(t){const keys=['Momentum','Liquidity','Volume','Wallet','Safety','Entry Quality'],point=(i,r)=>[150+Math.cos(i*Math.PI/3-Math.PI/2)*r,110+Math.sin(i*Math.PI/3-Math.PI/2)*r];return `<svg class="wheel" viewBox="0 0 300 220" role="img" aria-label="Factor scores">${[20,40,60,80].map(r=>`<polygon points="${keys.map((_,i)=>point(i,r).join(',')).join(' ')}" fill="none" stroke="#ffffff10"/>`).join('')}<polygon points="${keys.map((k,i)=>point(i,(t.scores[k]||0)*.8).join(',')).join(' ')}" fill="#66f4c81b" stroke="#66f4c8" stroke-width="1.5"/>${keys.map((k,i)=>{const [x,y]=point(i,103);return `<text x="${x}" y="${y}" text-anchor="middle" fill="#8293ab" font-size="8">${k==='Entry Quality'?'Entry':k}</text>`;}).join('')}</svg>`;}
 function tokenPage(){
  const t=tokens().find(t=>t.id===detail)||(signal()?.token.id===detail?signal().token:null)||(saved.history||[]).find(s=>s.token.id===detail)?.token;
  if(!t)return '<button class="back" data-action="back">← Back</button><p>This token is no longer in the recent observations.</p>';
  const keys=['Momentum','Liquidity','Volume','Wallet','Safety','Social','Entry Quality','Rug Risk','Risk','Overall'];
  return `<button class="back" data-action="back">← Back</button><div class="row">${avatar(t)}<div class="grow"><h2>${esc(t.name)}</h2><span class="quiet">${esc(t.symbol+' · '+t.chain.toUpperCase())}</span></div><button class="icon-button" data-watch="${esc(t.id)}" aria-label="Toggle watchlist">${watch.includes(t.id)?'★':'☆'}</button></div><p class="badge" style="margin:16px 0">ANALYSIS ONLY · ${esc(t.status)}</p>`+
  panel('Observed price',`<div class="price-large">${money(t.price)}</div>${chart(t)}<p class="footnote">${esc(t.source)} · ${new Date(t.fetched*1000).toLocaleTimeString()}</p>`)+panel('Factor analysis',wheel(t)+keys.map(k=>`<div class="score-row"><span>${k}</span><div class="bar"><div style="width:${Math.max(0,Math.min(100,t.scores[k]||0))}%"></div></div><b>${t.scores[k]==null?'—':Math.round(t.scores[k])}</b></div>`).join('')+'<p class="footnote">Wallet uses account concentration only. Missing factors are unknown. Scores are not calibrated probabilities.</p>')+
  panel('Market structure',`<div class="metrics two">${metric('Pool liquidity',compact(t.liquidity))}${metric('Market cap',compact(t.marketCap))}${metric('FDV',compact(t.fdv))}${metric('5m volume',compact(t.volume5))}${metric('5m buy txns',t.buys)}${metric('5m sell txns',t.sells)}</div><p class="footnote">Pool age: ${t.created?Math.floor((now()-t.created)/60)+' minutes':'Unavailable'}. Unique buyers and sellers are unavailable.</p>`)+
  panel('Position-size context',`<p style="font-size:12px">Larger orders can move the market. This app does not guarantee the same outcome for small and large investments.</p><label class="quiet" for="amount">HYPOTHETICAL ORDER · USD</label><input id="amount" value="${esc(orderSize)}" type="number" min="0" inputmode="decimal" placeholder="Enter amount" style="width:100%;margin-top:10px" data-liquidity="${t.liquidity}"><p id="size-context" class="footnote">Shows order size versus reported pool liquidity, not a slippage quote.</p>`)+
  panel('Security · '+t.security.source,`<p class="badge ${t.security.complete&&!t.security.danger?'':'warn'}">${t.security.danger?'SECURITY WARNING':t.security.complete?'AVAILABLE CHECKS COMPLETE':'INCOMPLETE — SIGNAL BLOCKED'}</p>${Object.entries(t.security.facts).map(([k,v])=>`<div class="kv"><span>${esc(k)}</span><span>${esc(v)}</span></div>`).join('')}`)+panel('Contract and pool',`<p class="contract">${esc(t.address)}</p><p class="contract">Pool: ${esc(t.pool)}</p>`)+panel('Why it is being watched',list(t.reasons))+panel('Risks',list(t.risks))+panel('Unavailable evidence',list(t.unavailable));
 }
 function history(){const rows=saved.history||[];return `<h1>Signal history</h1><p class="footnote">Real observed signals on this phone. These are not executed trades; fees, fills and partial exits are not simulated.</p>${rows.length?rows.map(s=>`<button class="token" data-history="${esc(s.id)}">${avatar(s.token)}<span class="grow"><strong>${esc(s.token.symbol)}</strong><small>${esc(s.closeReason||'Closed')}</small><small>${new Date(s.opened*1000).toLocaleString()}</small></span><span class="${s.exit!=null&&s.exit>=s.entry?'mint':'orange'}">${s.exit==null?'Unpriced':pct((s.exit/s.entry-1)*100)}</span></button>`).join(''):panel('A clean start','<div class="empty"><div class="emblem">◷</div><h2>No completed signals yet</h2><p>History starts when a real qualifying signal completes.</p></div>')}`;}
 function settings(){return `<button class="back" data-action="back">← Back</button><h1>Scanner status</h1>${panel('On-device radar',`${badge()}<p data-phase></p><p class="footnote">Live feeds connect automatically. Scanning runs while this app is visible. Returning to the app starts a fresh check.</p><button class="primary" data-action="refresh">${busy?'Scanning…':'Refresh now'}</button><p class="quiet">Last scan step: ${cycleDuration.toFixed(1)}s</p>`)}${panel('Feed health',(saved.state?.providers||[]).map(p=>`<div class="kv"><span>${esc(p.name)}</span><span class="${p.ok&&now()-p.at<120?'mint':'orange'}">${p.ok&&now()-p.at<120?'AVAILABLE':'RETRY / DELAYED'}</span></div>`).join('')||'<p>Waiting for feed checks.</p>')}${panel('Notifications','<h3>In-app alerts and haptics</h3><p class="footnote">This version does not scan or send market alerts while closed or screen-locked. No account, server or pairing code is required.</p>')}${activity()}<p class="footnote">ZK Meme Radar · Android 1.0.1<br>${disclaimer}</p>`;}
 function render(){
  const focus=document.activeElement,id=focus?.id,start=focus?.selectionStart;
  const pos=window.scrollY;
  let html=detail?tokenPage():tab==='home'?home():tab==='signal'?signalPage():tab==='market'?market():tab==='history'?history():tab==='settings'?settings():`<h1>Radar</h1>${panel(signal()?'Signal lock engaged':'Discovery mode',radar(true)+'<p class="scan-phase" data-phase></p><p class="footnote">Each dot is a real observed token. Stronger candidates sit closer to the centre. Dots are not buy recommendations.</p>')}${activity()}`;
  $('main').innerHTML=html;
  document.querySelectorAll('nav [data-tab]').forEach(b=>b.classList.toggle('selected',b.dataset.tab===tab&&!detail));
  renderStatus();updateTimer();
  if(id&&$(id)){try{$(id).focus({preventScroll:true});if(typeof start==='number')$(id).setSelectionRange(start,start);}catch{}}
  window.scrollTo(0,pos);
 }
 function navigate(next){tab=next;detail=null;selectedHistory=null;render();$('main').classList.remove('scroll-enter');void $('main').offsetWidth;$('main').classList.add('scroll-enter');window.scrollTo(0,0);}
 function back(){if(detail){detail=null;render();}else if(tab==='settings')navigate('home');else if(selectedHistory)navigate('history');else navigate('home');}
 function updateTimer(){document.querySelectorAll('[data-expires]').forEach(el=>{const seconds=Math.max(0,Math.floor(Number(el.dataset.expires)-now()));el.textContent=String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');});document.querySelectorAll('[data-hold-bar]').forEach(el=>{const end=Number(el.dataset.end),begin=Number(el.dataset.holdBar);el.style.width=Math.max(0,Math.min(100,(end-now())/Math.max(1,end-begin)*100))+'%';});}
 document.addEventListener('click',e=>{
  const b=e.target.closest('button');if(!b)return;
  if(b.dataset.tab){navigate(b.dataset.tab);return;}
  if(b.dataset.token){detail=b.dataset.token;render();window.scrollTo(0,0);return;}
  if(b.dataset.history){selectedHistory=b.dataset.history;tab='signal';detail=null;render();window.scrollTo(0,0);return;}
  if(b.dataset.watch){const id=b.dataset.watch;watch=watch.includes(id)?watch.filter(x=>x!==id):watch.concat(id);try{localStorage.setItem('watch',JSON.stringify(watch));}catch{}render();return;}
  if(b.dataset.filter){filter=b.dataset.filter;render();return;}
  if(b.dataset.action==='settings'){navigate('settings');return;}
  if(b.dataset.action==='back'){back();return;}
  if(b.dataset.action==='refresh'){if(!busy){clearTimeout(timer);tick();}toast(busy?'Scanner is checking feeds':'Next scan requested');}
 });
 document.addEventListener('input',e=>{
  if(e.target.id==='search'){query=e.target.value;$('results').innerHTML=marketRows();}
  if(e.target.id==='amount'){orderSize=e.target.value;const n=Number(e.target.value),liq=Number(e.target.dataset.liquidity);$('size-context').textContent=n>0&&Number.isFinite(n)&&liq>0?`Order / pool liquidity: ${(n/liq*100).toFixed(3)}%. This is not an executable slippage quote. Even small orders may be unsellable.`:'Shows order size versus reported pool liquidity, not a slippage quote.';}
 });
 document.addEventListener('change',e=>{if(e.target.id==='chain'){chain=e.target.value;render();}});
 document.addEventListener('error',e=>{if(e.target.tagName==='IMG')e.target.remove();},true);
 setInterval(()=>{updateTimer();renderStatus();},1000);
 window.RadarApp={foreground,back};
 render();foreground(Android.isForeground());
})();
