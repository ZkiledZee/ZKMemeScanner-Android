package com.zk.memeradar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.net.Uri;
import android.util.AtomicFile;
import android.view.HapticFeedbackConstants;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import javax.net.ssl.HttpsURLConnection;

public final class MainActivity extends Activity {
    private WebView web;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newFixedThreadPool(3);
    private final ExecutorService cancellation = Executors.newSingleThreadExecutor();
    private final Set<HttpsURLConnection> connections = ConcurrentHashMap.newKeySet();
    private volatile boolean foreground = false;
    private volatile int epoch = 0;
    private AtomicFile stateFile;
    private static final String ORIGIN = "https://radar.local/";
    private static final Set<String> HOSTS = new HashSet<>(Arrays.asList("api.dexscreener.com", "api.geckoterminal.com", "api.gopluslabs.io", "api.mainnet-beta.solana.com"));
    private static final Set<String> ASSETS = new HashSet<>(Arrays.asList("index.html", "style.css", "bridge.js", "scanner.js", "app.js"));

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        stateFile = new AtomicFile(new File(getFilesDir(), "radar-state.json"));
        createWebView();
    }
    @SuppressLint("SetJavaScriptEnabled")
    private void createWebView() {
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(7,12,22));
        web.setFitsSystemWindows(true);
        web.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if ("radar.local".equals(uri.getHost())) {
                    String name=uri.getPath()==null?"":uri.getPath().substring(1);
                    if(!ASSETS.contains(name)) return new WebResourceResponse("text/plain","UTF-8",404,"Not found",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
                    try {
                        String mime=name.endsWith(".html")?"text/html":name.endsWith(".css")?"text/css":"application/javascript";
                        return new WebResourceResponse(mime,"UTF-8",getAssets().open(name));
                    } catch(IOException e) { return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0])); }
                }
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
            @Override public void onPageFinished(WebView view,String url) {
                if(url.equals(ORIGIN+"index.html")) evaluate("window.RadarApp&&RadarApp.foreground("+foreground+")");
            }
            @Override public boolean onRenderProcessGone(WebView view,RenderProcessGoneDetail detail) {
                foreground=false;cancelRequests();view.destroy();web=null;
                LinearLayout box=new LinearLayout(MainActivity.this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(32,80,32,32);
                TextView title=new TextView(MainActivity.this);title.setText("Radar needs to restart. Your saved signal state is preserved.");title.setTextColor(Color.WHITE);title.setTextSize(18);box.addView(title);
                Button retry=new Button(MainActivity.this);retry.setText("Resume radar");retry.setOnClickListener(v->{foreground=true;createWebView();});box.addView(retry);setContentView(box);return true;
            }
        });
        setContentView(web);
        web.loadUrl(ORIGIN+"index.html");
    }
    private void evaluate(String code) { if(web!=null&&!isFinishing()) web.evaluateJavascript(code,null); }
    private void cancelRequests() {
        epoch++;
        for(HttpsURLConnection c:connections){if(!cancellation.isShutdown())cancellation.execute(c::disconnect);}
        connections.clear();
    }
    @Override protected void onResume(){super.onResume();foreground=true;getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(web!=null){web.onResume();evaluate("window.RadarApp&&RadarApp.foreground(true)");}}
    @Override protected void onPause(){foreground=false;evaluate("window.RadarApp&&RadarApp.foreground(false)");cancelRequests();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(web!=null)web.onPause();super.onPause();}
    @Override protected void onDestroy(){cancelRequests();network.shutdownNow();cancellation.shutdown();if(web!=null){web.removeJavascriptInterface("Android");web.destroy();web=null;}super.onDestroy();}
    @Override public void onBackPressed(){if(web!=null)evaluate("window.RadarApp&&RadarApp.back()");else super.onBackPressed();}
    public final class Bridge {
        @JavascriptInterface public boolean isForeground(){return foreground;}
        @JavascriptInterface public String uuid(){return UUID.randomUUID().toString();}
        @JavascriptInterface public synchronized String readState(){
            if(!stateFile.getBaseFile().exists())return "{}";
            try{return new String(stateFile.readFully(),StandardCharsets.UTF_8);}catch(IOException e){return "{\"storageError\":true}";}
        }
        @JavascriptInterface public synchronized boolean saveState(String value){
            if(!foreground||value.length()>8000000)return false;
            FileOutputStream out=null;
            try{
                JSONObject s=new JSONObject(value);
                if(!s.has("state")||!s.has("history"))return false;
                out=stateFile.startWrite();out.write(value.getBytes(StandardCharsets.UTF_8));stateFile.finishWrite(out);return true;
            }catch(Exception e){if(out!=null)stateFile.failWrite(out);return false;}
        }
        @JavascriptInterface public void haptic(){main.post(()->{if(web!=null&&foreground)web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);});}
        @JavascriptInterface public void cancel(){cancelRequests();}
        @JavascriptInterface public void request(String id,String address,String options){
            if(!foreground||network.isShutdown()||id.length()>80)return;
            final int ticket=epoch;
            network.execute(()->{
                HttpsURLConnection connection=null;int status=0;String body="",error="";
                try{
                    URL url=new URL(address);
                    if(!"https".equals(url.getProtocol())||!HOSTS.contains(url.getHost())||url.getUserInfo()!=null||(url.getPort()!=-1&&url.getPort()!=443))throw new IOException("Unsupported market host");
                    if(!foreground||ticket!=epoch)return;
                    JSONObject opts=new JSONObject(options);
                    connection=(HttpsURLConnection)url.openConnection();connections.add(connection);
                    connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(8000);connection.setReadTimeout(10000);
                    connection.setRequestProperty("Accept","application/json");
                    String method=opts.optString("method","GET");
                    if(!method.equals("GET")&&!method.equals("POST"))throw new IOException("Unsupported method");
                    connection.setRequestMethod(method);
                    if(method.equals("POST")){
                        byte[] bytes=opts.optString("body","").getBytes(StandardCharsets.UTF_8);
                        if(bytes.length>8192)throw new IOException("Request too large");
                        connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json");
                        try(OutputStream output=connection.getOutputStream()){output.write(bytes);}
                    }
                    status=connection.getResponseCode();
                    InputStream input=status<400?connection.getInputStream():connection.getErrorStream();
                    if(input!=null)try(InputStream in=input;ByteArrayOutputStream output=new ByteArrayOutputStream()){
                        byte[] bytes=new byte[8192];int n;
                        while((n=in.read(bytes))!=-1){if(ticket!=epoch||!foreground)return;output.write(bytes,0,n);if(output.size()>5000000)throw new IOException("Response too large");}
                        body=output.toString(StandardCharsets.UTF_8.name());
                    }
                }catch(Exception e){error="Market connection interrupted";}
                finally{if(connection!=null){connections.remove(connection);connection.disconnect();}}
                final String result="window.RadarNative&&RadarNative.receive("+JSONObject.quote(id)+","+status+","+JSONObject.quote(body)+","+JSONObject.quote(error)+")";
                main.post(()->{if(foreground&&ticket==epoch)evaluate(result);});
            });
        }
    }
}
