from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
for p in (root/'app/src/main').rglob('*.xml'):ET.parse(p)
for name in ['index.html','style.css','app.js','bridge.js','scanner.js']:
    assert (root/'app/src/main/assets'/name).is_file(),name
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
assert manifest.find('application').get(ns+'usesCleartextTraffic')=='false'
assert manifest.find('application').get(ns+'allowBackup')=='false'
assert 'com.zk.memeradar' in (root/'app/build.gradle').read_text()
assert (root/'signing/personal-test.jks').stat().st_size>1000
print('Android source, manifest and bundled assets verified')

# The minimum supported device is API 26. This theme flag needs API 27.
base_theme=ET.parse(root/'app/src/main/res/values/styles.xml').getroot()
assert not any(item.get('name')=='android:windowLightNavigationBar' for item in base_theme.iter('item')), 'API-27 navigation-bar flag must not be in the API-26 base theme'
print('API-26 theme compatibility regression check passed')
