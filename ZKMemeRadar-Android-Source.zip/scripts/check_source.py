from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
for p in (root/'app/src/main').rglob('*.xml'):ET.parse(p)
for name in ['index.html','style.css','app.js','bridge.js','scanner.js']:
    assert (root/'app/src/main/assets'/name).is_file(),name
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
assert manifest.find('application').get(ns+'usesCleartextTraffic')=='false'
assert manifest.find('application').get(ns+'allowBackup')=='false'
assert 'com.zk.memeradar' in (root/'app/build.gradle').read_text()
assert (root/'signing/personal-test.jks').stat().st_size>1000
print('Android source, manifest and bundled assets verified')
