import sys,zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
    assert z.testzip() is None,'APK archive is corrupt'
    names=set(z.namelist())
    for name in ['AndroidManifest.xml','classes.dex','resources.arsc','assets/index.html','assets/style.css','assets/app.js','assets/bridge.js','assets/scanner.js']:
        assert name in names,'Missing APK file: '+name
    assert not any(n.startswith('assets/tests/') for n in names),'Test fixtures must not ship'
print('APK contents verified')
