# ZK Meme Radar — Android 1.0

## Build your APK from one ZIP

Use a separate GitHub repository for Android so the iPhone workflow stays intact.

1. Create `.github/workflows/build.yml` using the supplied **build.yml**.
2. Upload **ZKMemeRadar-Android-Source.zip** to the repository root. Keep that exact filename; do not extract it.
3. Open **Actions → Build APK**. The ZIP upload starts a build automatically, or choose **Run workflow**.
4. Open the successful run and download **ZKMemeRadar-APK** under Artifacts.
5. Extract the artifact ZIP and open **ZKMemeRadar.apk** on your Android phone. Allow installation from that browser/file manager when Android asks.

No Netlify, account, API key, wallet, pairing code or weekly signing is needed. Android 8.0 or newer with an up-to-date Android System WebView is required. The APK is for personal sideload testing, not a Play Store release.

## Behaviour and interface

- The existing dark mint-and-blue design, animated radar sweep, pulsing real candidate dots, live sparklines, token images, factor wheel and charted entry/stop/target levels.
- Home, Signal, Radar, Market and History. Search tokens/contracts, filter by chain, view momentum/new/volume candidates and keep a local watchlist.
- Real DEX Screener and GeckoTerminal discovery across Solana, Base, Ethereum and BNB. No production demo coins. Public feeds cover only part of the market and may include non-meme assets.
- Transparent scoring using observed momentum, liquidity, volume, concentration and entry quality. Missing critical security evidence blocks entries. GoPlus/Solana RPC checks are used where available; no fabricated wallet, social or insider attribution.
- At least five minutes and ten observations are required before a candidate can qualify. Leading candidates are sampled more frequently; discovery continues in small stages.
- One active signal at a time, with persisted timer, reasons, entry zone, stop, targets and monitored exit conditions. New signals open the Signal screen automatically and trigger in-app notices/haptics.
- Persistent provider cooldowns, timeouts, automatic retries and foreground recovery. Network work runs outside the UI thread. One failing discovery request does not discard previous successful observations.
- Atomic local state saves before displaying a new entry. Up to 200 completed observations; history is not backtested or fabricated. Unobserved gaps close signals without inventing exit prices.
- Optional order-size context compares a hypothetical USD amount with reported pool liquidity. It is not an executable quote or slippage calculation.

**Keep the app open to scan.** The screen stays awake while it is visible. Backgrounding, closing or locking pauses monitoring; this version does not provide closed-app market notifications. No trades are executed. Reopening restores state and checks current conditions.

There is no guarantee of profit, coverage of every coin, or suitability for every investment size. Fees, transfer taxes, price impact, slippage and inability to sell can overwhelm any apparent opportunity. Scores are heuristics, not win or rug probabilities.

## Project

`app/src/main/java/`: Android Activity, secure local UI host, HTTPS bridge and atomic persistence.

`app/src/main/assets/`: bundled HTML/CSS interface and deterministic JavaScript scanner. All executable UI/engine code ships inside the APK; the app does not load a hosted site or remote scripts. Only JSON market data and optional token images are fetched.

`tests/`: synthetic fixtures used only by tests, excluded from the APK.

`scripts/`: source and APK validation.

The build uses AGP 8.9.2, Gradle 8.11.1, Java 17 and Android API 35. Google documents this compatible toolchain at https://developer.android.com/build/releases/agp-8-9-0-release-notes . A locally installed Gradle 8.11.1 and Android SDK can also build it with `gradle :app:assembleRelease :app:lintRelease`.

## Personal signing

A **public development signing key** is deliberately included at `signing/personal-test.jks` (alias `androiddebugkey`, password `android`). It keeps this no-setup personal test APK update-compatible across GitHub runs. It is not a private production credential. Keep it unchanged for personal APK updates. For public distribution, replace it with your own protected release key and signing configuration; do not use this public key to authenticate a trusted commercial app. Release builds disable Android debugging.

## Verification

See VERIFICATION.md for actual checks and remaining device/build verification. No claim of error-free operation or guaranteed live-feed availability is made.

Signals are algorithmic market observations and not guaranteed outcomes. Meme coins are highly speculative and can rapidly lose their entire value.
