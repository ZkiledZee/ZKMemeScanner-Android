# Verification

- 11 Android bundled-engine tests passed: entry checks, null scores, one-signal persistence, monitoring-gap closure, missing feeds/security, HTTP bridge response shape, malformed quotes, cooldown persistence, recovery without reinstall, incremental discovery and security-report expiry.
- App and bridge JavaScript syntax checked with Node.
- DOM UI interaction test passed: five tabs, signal, search, token analysis, amount context, watchlist, settings and back navigation. This is not a visual Android-device test.
- Android Java source compiled successfully with ECJ against Android API 35 plus JDK 17 libraries. Deprecated compatibility API warnings remain; this is not a full Gradle/APK build.
- Manifest, resource XML, app assets and development keystore checked by scripts/check_source.py.
- GitHub workflow installs the documented compatible toolchain, runs engine/source checks, compiles and lints the release build, verifies APK signing and verifies bundled assets before artifact upload.
- A complete Android Gradle build and physical-device live-feed verification have not yet been completed in this workspace. They must not be described as passed until the workflow/device checks run.
- Test fixtures are outside app/src/main/assets and are not packaged in the production scanner.

## Android 1.0.1 build fix

The supplied GitHub annotations identified `android:windowLightNavigationBar` as an unsupported base-theme attribute for the minimum SDK. Removed this redundant API-27 attribute from the API-26 base theme; the dark theme already supplies the intended navigation-icon appearance. Added a source regression check. Lint remains enabled and fatal errors still block packaging.

Updated checkout, Java, Node, Gradle setup and artifact actions to maintained versions documented by their repositories. The workflow now automatically triggers only for source ZIP uploads; creating the workflow before the ZIP is present no longer starts a doomed automatic build. Manual dispatch remains available.

The exact compatibility check passed locally. The corrected full GitHub Gradle/lint run still needs to execute.
